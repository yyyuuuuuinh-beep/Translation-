package com.example.gametranslator

import android.content.Context

/** إعدادات المستخدم (SharedPreferences). تُقرأ عند الاستخدام فتُطبَّق على الحوار التالي مباشرة. */
class AppSettings(context: Context) {
    private val p = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** دورة الفحص (ms): أقل = أسرع وأثقل. */
    var scanIntervalMs: Int
        get() = p.getInt("scan", 300)
        set(v) { p.edit().putInt("scan", v).apply() }

    /** أقصى فاصل بين الإخفاءات اللحظية للتغطية (ms): أكبر = وميض أقل وكشف أبطأ للحوار الجديد. */
    var peekIntervalMs: Int
        get() = p.getInt("peek", 1200)
        set(v) { p.edit().putInt("peek", v).apply() }

    /** حجم خط الترجمة (% من الحجم التلقائي). */
    var fontScalePercent: Int
        get() = p.getInt("font", 100)
        set(v) { p.edit().putInt("font", v).apply() }

    /** شفافية نافذة التغطية (%). الحد الأقصى 80 كي يسمح أندرويد 12+ بمرور اللمس للعبة. */
    var maskOpacity: Int
        get() = p.getInt("opacity", 80).coerceIn(30, 80)
        set(v) { p.edit().putInt("opacity", v.coerceIn(30, 80)).apply() }

    var maskColor: Int
        get() = p.getInt("maskColor", PRESETS[0].second)
        set(v) { p.edit().putInt("maskColor", v).apply() }

    var textColor: Int
        get() = p.getInt("textColor", PRESETS[0].third)
        set(v) { p.edit().putInt("textColor", v).apply() }

    /** تكبير الصورة 2× قبل OCR لتحسين قراءة الخطوط الصغيرة (أبطأ). */
    var sharpenSmallText: Boolean
        get() = p.getBoolean("sharpen", false)
        set(v) { p.edit().putBoolean("sharpen", v).apply() }

    companion object {
        /** (الاسم، لون الإطار، لون النص) */
        val PRESETS = listOf(
            Triple("أسود / أبيض", 0xFF000000.toInt(), 0xFFFFFFFF.toInt()),
            Triple("رمادي / أبيض", 0xFF303030.toInt(), 0xFFFFFFFF.toInt()),
            Triple("كحلي / أصفر", 0xFF0B1F4D.toInt(), 0xFFFFE066.toInt()),
            Triple("بيج / أسود", 0xFFF2E3B8.toInt(), 0xFF000000.toInt())
        )
    }
}
