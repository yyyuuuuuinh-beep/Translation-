package com.example.gametranslator

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/** قطعة نص مرصودة: مكانها على الشاشة + الترجمة العربية + عدد أسطرها الأصلية. */
data class MaskItem(val rect: Rect, val text: String, val lines: Int)

/**
 * النوافذ العائمة:
 *  1) لوحة التحكم (قابلة للمس): ✥ سحب | ▶/⏹ تشغيل | ⛶ ضبط المربع | ✕ إغلاق
 *  2) مربع تحديد منطقة الحوار (يظهر أثناء الضبط فقط)
 *  3) نافذة التغطية (Mask): بملء الشاشة، FLAG_NOT_TOUCHABLE، ترسم مستطيلاً أسود فوق كل نص
 *     إنجليزي ثم الترجمة العربية فوقه في نفس المكان.
 *  4) مراقب لمس 1×1 بكسل (WATCH_OUTSIDE_TOUCH) يُعلم الخدمة بأي ضغطة لتفحص تغيّر الحوار فوراً.
 */
class FloatingOverlayManager(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onScanStateChanged(scanning: Boolean)
        fun onCloseRequested()
        fun onUserTap()
    }

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = context.getSharedPreferences("overlay", Context.MODE_PRIVATE)
    private val density = context.resources.displayMetrics.density
    private val main = Handler(Looper.getMainLooper())
    private val settings = AppSettings(context)
    private fun dp(v: Int) = (v * density).toInt()
    private fun dpf(v: Float) = v * density

    private var panel: LinearLayout? = null
    private lateinit var toggleBtn: TextView
    private lateinit var editBtn: TextView

    private var boxView: BoxView? = null

    private var maskView: MaskView? = null
    private var maskParams: WindowManager.LayoutParams? = null

    private var tapView: View? = null

    @Volatile private var scanRect: Rect = loadRect()
    private var isScanning = false
    private var isEditing = false

    // ---------------------------------------------------------------- helpers

    private val baseFlags = FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS

    private fun newParams(w: Int, h: Int, flags: Int) =
        WindowManager.LayoutParams(w, h, TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

    private fun round(color: Int, radius: Float) =
        GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = radius; setColor(color) }

    fun screenSize(): Point =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            @Suppress("DEPRECATION")
            Point().also { wm.defaultDisplay.getRealSize(it) }
        }

    fun getScanRect(): Rect = Rect(scanRect)

    private fun loadRect(): Rect {
        val s = screenSize()
        val x = prefs.getInt("x", (s.x * 0.05f).toInt())
        val y = prefs.getInt("y", (s.y * 0.65f).toInt())
        val w = prefs.getInt("w", (s.x * 0.90f).toInt())
        val h = prefs.getInt("h", (s.y * 0.30f).toInt())
        return Rect(x, y, x + w, y + h)
    }

    private fun saveRect(r: Rect) {
        scanRect = Rect(r)
        prefs.edit().putInt("x", r.left).putInt("y", r.top)
            .putInt("w", r.width()).putInt("h", r.height()).apply()
    }

    // ------------------------------------------------------------ show / panel

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        addMaskWindow()

        fun btn(label: String) = TextView(context).apply {
            text = label
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        }
        val handle = btn("✥")
        toggleBtn = btn("▶")
        editBtn = btn("⛶")
        val closeBtn = btn("✕")

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(0xCC202020.toInt(), dp(26).toFloat())
            setPadding(dp(6), dp(6), dp(6), dp(6))
            addView(handle); addView(toggleBtn); addView(editBtn); addView(closeBtn)
        }
        val p = newParams(WRAP_CONTENT, WRAP_CONTENT, baseFlags or FLAG_NOT_TOUCH_MODAL).apply {
            x = dp(8); y = dp(80)
        }

        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = ox + (e.rawX - sx).toInt()
                        p.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(row, p)
                    }
                }
                return true
            }
        })
        toggleBtn.setOnClickListener { setScanning(!isScanning) }
        editBtn.setOnClickListener { if (isEditing) finishEditing() else startEditing() }
        closeBtn.setOnClickListener { listener.onCloseRequested() }

        panel = row
        wm.addView(row, p)
    }

    private fun setScanning(on: Boolean) {
        if (on && isEditing) finishEditing()
        isScanning = on
        toggleBtn.text = if (on) "⏹" else "▶"
        toggleBtn.setTextColor(if (on) Color.parseColor("#66FF66") else Color.WHITE)
        if (on) addTapWatcher() else { removeTapWatcher(); clearMasks() }
        listener.onScanStateChanged(on)
    }

    // ------------------------------------------------------------ box editor

    private fun startEditing() {
        if (isScanning) setScanning(false)
        val r = scanRect
        val p = newParams(r.width(), r.height(), baseFlags or FLAG_NOT_TOUCH_MODAL).apply {
            x = r.left; y = r.top
        }
        val v = BoxView(context, p)
        boxView = v
        wm.addView(v, p)
        isEditing = true
        editBtn.text = "✔"
    }

    private fun finishEditing() {
        boxView?.let { runCatching { wm.removeView(it) } }
        boxView = null
        isEditing = false
        if (::editBtn.isInitialized) editBtn.text = "⛶"
    }

    @SuppressLint("ViewConstructor")
    private inner class BoxView(ctx: Context, private val p: WindowManager.LayoutParams) : View(ctx) {
        private val handleSize = dp(44)
        private val minSize = dp(80)
        private val fill = Paint().apply { color = 0x3300AAFF }
        private val stroke = Paint().apply {
            color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = dp(3).toFloat()
        }
        private val solid = Paint().apply { color = Color.YELLOW }
        private val label = Paint().apply { color = Color.WHITE; textSize = dp(14).toFloat() }
        private var lastX = 0f; private var lastY = 0f
        private var resizing = false

        override fun onDraw(c: Canvas) {
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), stroke)
            c.drawRect(width - handleSize.toFloat(), height - handleSize.toFloat(),
                width.toFloat(), height.toFloat(), solid)
            c.drawText("Dialogue Scan Box", dp(8).toFloat(), dp(20).toFloat(), label)
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(e: MotionEvent): Boolean {
            val screen = screenSize()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.rawX; lastY = e.rawY
                    resizing = e.x > width - handleSize && e.y > height - handleSize
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - lastX).toInt(); val dy = (e.rawY - lastY).toInt()
                    lastX = e.rawX; lastY = e.rawY
                    if (resizing) {
                        p.width = min(max(minSize, p.width + dx), screen.x - p.x)
                        p.height = min(max(minSize, p.height + dy), screen.y - p.y)
                    } else {
                        p.x = min(max(0, p.x + dx), screen.x - p.width)
                        p.y = min(max(0, p.y + dy), screen.y - p.height)
                    }
                    wm.updateViewLayout(this, p)
                    scanRect = Rect(p.x, p.y, p.x + p.width, p.y + p.height)
                }
                MotionEvent.ACTION_UP -> saveRect(Rect(p.x, p.y, p.x + p.width, p.y + p.height))
            }
            return true
        }
    }

    // ------------------------------------------------------- mask (in-place) window

    private fun addMaskWindow() {
        val s = screenSize()
        val v = MaskView(context)
        // FLAG_NOT_TOUCHABLE: اللمس ينفذ إلى اللعبة.
        // alpha = 0.8: شرط أندرويد 12+ كي لا يمنع النظام اللمس العابر عبر النوافذ العائمة (الحد 0.8).
        val p = newParams(s.x, s.y, baseFlags or FLAG_NOT_TOUCHABLE).apply {
            x = 0; y = 0; alpha = 0.8f
        }
        maskView = v; maskParams = p
        wm.addView(v, p)
    }

    /** يعرض الإطارات السوداء + الترجمة (آمنة للاستدعاء من أي خيط). */
    fun showMasks(items: List<MaskItem>) {
        main.post {
            // تطبيق الشفافية من الإعدادات (<= 0.8 ليمر اللمس على أندرويد 12+)
            val a = settings.maskOpacity / 100f
            val p = maskParams; val v = maskView
            if (p != null && v != null && p.alpha != a) {
                p.alpha = a
                runCatching { wm.updateViewLayout(v, p) }
            }
            maskView?.setItems(items)
        }
    }

    /** إخفاء/إظهار مؤقت (يُستخدم لالتقاط الشاشة بدون التغطية). */
    fun setMasksVisible(visible: Boolean) {
        main.post { maskView?.visibility = if (visible) View.VISIBLE else View.INVISIBLE }
    }

    fun clearMasks() { main.post { maskView?.setItems(emptyList()) } }

    /** عند تدوير الشاشة. */
    fun onScreenChanged() {
        main.post {
            val s = screenSize()
            maskParams?.let { it.width = s.x; it.height = s.y; maskView?.let { v -> runCatching { wm.updateViewLayout(v, it) } } }
            maskView?.setItems(emptyList())
        }
    }

    private inner class MaskView(ctx: Context) : View(ctx) {
        private inner class Drawn(val box: Rect, val layout: StaticLayout, val textLeft: Int, val textTop: Int)

        private var drawn: List<Drawn> = emptyList()
        private val bg = Paint()

        fun setItems(items: List<MaskItem>) {
            bg.color = settings.maskColor
            drawn = items.map { build(it) }
            visibility = View.VISIBLE
            invalidate()
        }

        private fun build(item: MaskItem): Drawn {
            val pad = dp(4)
            val box = Rect(item.rect).apply { inset(-pad, -pad) }
            val textW = max(dp(20), item.rect.width())
            val maxH = item.rect.height()

            // حجم الخط: يبدأ من ارتفاع السطر الأصلي ثم يصغر حتى تتسع الترجمة داخل الإطار
            val lineH = item.rect.height().toFloat() / max(1, item.lines)
            val fs = settings.fontScalePercent / 100f
            var size = (lineH * 0.8f * fs).coerceIn(dpf(10f) * fs, dpf(26f) * fs)
            val minSize = dpf(9f)
            var layout: StaticLayout
            while (true) {
                val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = settings.textColor; textSize = size }
                layout = StaticLayout.Builder.obtain(item.text, 0, item.text.length, paint, textW)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setIncludePad(false)
                    .build()
                if (layout.height <= maxH || size <= minSize) break
                size -= density
            }
            // إن لم تتسع الترجمة حتى بأصغر خط، يتمدد الإطار الأسود للأسفل
            if (layout.height > maxH) box.bottom = box.top + layout.height + 2 * pad
            val top = box.top + pad + max(0, (box.height() - 2 * pad - layout.height) / 2)
            return Drawn(box, layout, box.left + pad, top)
        }

        override fun onDraw(c: Canvas) {
            for (d in drawn) {
                c.drawRect(d.box, bg)
                c.save()
                c.translate(d.textLeft.toFloat(), d.textTop.toFloat())
                d.layout.draw(c)
                c.restore()
            }
        }
    }

    // -------------------------------------------------------------- tap watcher

    /** نافذة 1×1 تستقبل ACTION_OUTSIDE عند أي لمسة في اللعبة (بدون إحداثيات) => فحص فوري للتغيير. */
    @SuppressLint("ClickableViewAccessibility")
    private fun addTapWatcher() {
        if (tapView != null) return
        val v = View(context).apply {
            setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) listener.onUserTap()
                false
            }
        }
        val p = newParams(1, 1, FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCH_MODAL or
                FLAG_WATCH_OUTSIDE_TOUCH or FLAG_LAYOUT_NO_LIMITS)
        wm.addView(v, p)
        tapView = v
    }

    private fun removeTapWatcher() {
        tapView?.let { runCatching { wm.removeView(it) } }
        tapView = null
    }

    fun destroy() {
        removeTapWatcher()
        finishEditing()
        maskView?.let { runCatching { wm.removeView(it) } }
        maskView = null
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }
}
