package com.example.gametranslator

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * يدير ثلاث نوافذ عائمة:
 *  1) لوحة التحكم (قابلة للمس): سحب ✥ | تشغيل/إيقاف ▶ | ضبط المربع ⛶ | إغلاق ✕
 *  2) مربع تحديد منطقة الحوار (قابل للسحب والتحجيم) - يظهر فقط أثناء الضبط
 *  3) نافذة النص المترجم: FLAG_NOT_TOUCHABLE => اللمس ينفذ مباشرة إلى اللعبة
 *
 * ملاحظة: النص المترجم يوضع دائماً خارج مربع المسح حتى لا يلتقطه OCR.
 */
class FloatingOverlayManager(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onScanStateChanged(scanning: Boolean)
        fun onCloseRequested()
    }

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = context.getSharedPreferences("overlay", Context.MODE_PRIVATE)
    private val density = context.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private lateinit var toggleBtn: TextView
    private lateinit var editBtn: TextView

    private var boxView: BoxView? = null
    private var boxParams: WindowManager.LayoutParams? = null

    private var translationView: TextView? = null
    private var translationParams: WindowManager.LayoutParams? = null
    private var translationAttached = false

    @Volatile private var scanRect: Rect = loadRect()
    private var isScanning = false
    private var isEditing = false

    // ---------------------------------------------------------------- helpers

    private val baseFlags = FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS

    private fun newParams(w: Int, h: Int, flags: Int) =
        WindowManager.LayoutParams(w, h, TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

    private fun round(color: Int, radius: Float) =
        GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = radius; setColor(color) }

    /** حجم الشاشة الحقيقي (نفس حجم لقطة MediaProjection). */
    fun screenSize(): Point =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            @Suppress("DEPRECATION")
            Point().also { wm.defaultDisplay.getRealSize(it) }
        }

    /** مستطيل المسح الحالي بإحداثيات الشاشة (بكسل). */
    fun getScanRect(): Rect = Rect(scanRect)

    private fun loadRect(): Rect {
        val s = screenSize()
        val x = prefs.getInt("x", (s.x * 0.05f).toInt())
        val y = prefs.getInt("y", (s.y * 0.65f).toInt())
        val w = prefs.getInt("w", (s.x * 0.90f).toInt())
        val h = prefs.getInt("h", (s.y * 0.30f).toInt())
        return Rect(x, y, x + w, y + h)
    }

    private fun saveRect(r: Rect) {
        scanRect = Rect(r)
        prefs.edit().putInt("x", r.left).putInt("y", r.top)
            .putInt("w", r.width()).putInt("h", r.height()).apply()
    }

    // ------------------------------------------------------------ control panel

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        fun btn(label: String) = TextView(context).apply {
            text = label
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        }

        val handle = btn("✥")
        toggleBtn = btn("▶")
        editBtn = btn("⛶")
        val closeBtn = btn("✕")

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(0xCC202020.toInt(), dp(26).toFloat())
            setPadding(dp(6), dp(6), dp(6), dp(6))
            addView(handle); addView(toggleBtn); addView(editBtn); addView(closeBtn)
        }
        // لوحة التحكم قابلة للمس (بدون NOT_TOUCHABLE) لكن اللمس خارجها يمر للعبة
        val p = newParams(WRAP_CONTENT, WRAP_CONTENT, baseFlags or FLAG_NOT_TOUCH_MODAL).apply {
            x = dp(8); y = dp(80)
        }

        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = ox + (e.rawX - sx).toInt()
                        p.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(row, p)
                    }
                }
                return true
            }
        })
        toggleBtn.setOnClickListener { setScanning(!isScanning) }
        editBtn.setOnClickListener { if (isEditing) finishEditing() else startEditing() }
        closeBtn.setOnClickListener { listener.onCloseRequested() }

        panel = row; panelParams = p
        wm.addView(row, p)
    }

    private fun setScanning(on: Boolean) {
        if (on && isEditing) finishEditing()
        isScanning = on
        toggleBtn.text = if (on) "⏹" else "▶"
        toggleBtn.setTextColor(if (on) Color.parseColor("#66FF66") else Color.WHITE)
        if (!on) showTranslation(null)
        listener.onScanStateChanged(on)
    }

    // ------------------------------------------------------------ box editor

    private fun startEditing() {
        if (isScanning) setScanning(false)
        val r = scanRect
        val p = newParams(r.width(), r.height(), baseFlags or FLAG_NOT_TOUCH_MODAL).apply {
            x = r.left; y = r.top
        }
        val v = BoxView(context, p)
        boxView = v; boxParams = p
        wm.addView(v, p)
        isEditing = true
        editBtn.text = "✔"
    }

    private fun finishEditing() {
        boxView?.let { runCatching { wm.removeView(it) } }
        boxView = null; boxParams = null
        isEditing = false
        editBtn.text = "⛶"
    }

    /** المربع نفسه: سحب = تحريك، سحب الزاوية السفلية اليمنى = تغيير الحجم. */
    @SuppressLint("ViewConstructor")
    private inner class BoxView(ctx: Context, private val p: WindowManager.LayoutParams) : View(ctx) {
        private val handleSize = dp(44)
        private val minSize = dp(80)
        private val fill = Paint().apply { color = 0x3300AAFF }
        private val stroke = Paint().apply {
            color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = dp(3).toFloat()
        }
        private val solid = Paint().apply { color = Color.YELLOW }
        private val label = Paint().apply { color = Color.WHITE; textSize = dp(14).toFloat() }
        private var lastX = 0f; private var lastY = 0f
        private var resizing = false

        override fun onDraw(c: Canvas) {
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), stroke)
            c.drawRect(width - handleSize.toFloat(), height - handleSize.toFloat(),
                width.toFloat(), height.toFloat(), solid)
            c.drawText("Dialogue Scan Box", dp(8).toFloat(), dp(20).toFloat(), label)
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(e: MotionEvent): Boolean {
            val screen = screenSize()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.rawX; lastY = e.rawY
                    resizing = e.x > width - handleSize && e.y > height - handleSize
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - lastX).toInt(); val dy = (e.rawY - lastY).toInt()
                    lastX = e.rawX; lastY = e.rawY
                    if (resizing) {
                        p.width = min(max(minSize, p.width + dx), screen.x - p.x)
                        p.height = min(max(minSize, p.height + dy), screen.y - p.y)
                    } else {
                        p.x = min(max(0, p.x + dx), screen.x - p.width)
                        p.y = min(max(0, p.y + dy), screen.y - p.height)
                    }
                    wm.updateViewLayout(this, p)
                    scanRect = Rect(p.x, p.y, p.x + p.width, p.y + p.height)
                }
                MotionEvent.ACTION_UP -> saveRect(Rect(p.x, p.y, p.x + p.width, p.y + p.height))
            }
            return true
        }
    }

    // ------------------------------------------------------ translation overlay

    /** يعرض النص العربي (أو يخفيه إذا كان null). يجب استدعاؤها من الـ Main thread. */
    fun showTranslation(text: String?) {
        if (text.isNullOrBlank()) {
            translationView?.takeIf { translationAttached }?.let { runCatching { wm.removeView(it) } }
            translationAttached = false
            return
        }
        val screen = screenSize()
        val box = scanRect
        val w = min(screen.x, max(box.width(), (screen.x * 0.6f).toInt()))
        val x = min(max(0, box.left), screen.x - w)

        val tv = translationView ?: TextView(context).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            background = round(0xCC000000.toInt(), dp(10).toFloat())
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }.also { translationView = it }
        tv.text = text

        // قياس الارتفاع ثم اختيار المكان خارج المربع: تحته إن وُجد مكان وإلا فوقه
        tv.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = tv.measuredHeight
        val y = if (box.bottom + h + dp(8) <= screen.y) box.bottom + dp(8)
        else max(0, box.top - h - dp(8))

        // FLAG_NOT_TOUCHABLE: اللمس يمر مباشرة إلى اللعبة تحته
        val p = translationParams ?: newParams(w, WRAP_CONTENT, baseFlags or FLAG_NOT_TOUCHABLE)
            .also { translationParams = it }
        p.width = w; p.x = x; p.y = y

        if (translationAttached) wm.updateViewLayout(tv, p)
        else { wm.addView(tv, p); translationAttached = true }
    }

    fun destroy() {
        showTranslation(null)
        finishEditing()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }
}
