package com.example.gametranslator

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/** الأذونات + تشغيل الخدمة + شاشة الإعدادات. */
class MainActivity : ComponentActivity() {

    private lateinit var statusView: TextView
    private lateinit var settings: AppSettings
    private val density by lazy { resources.displayMetrics.density }
    private fun dp(v: Int) = (v * density).toInt()

    private val overlayLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) requestNotifications()
            else setStatus("لم يتم منح إذن العرض فوق التطبيقات")
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { requestProjection() }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, res.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_DATA, data)
                }
                startForegroundService(intent)
                setStatus("الخدمة تعمل ✓ افتح اللعبة واستخدم الأزرار العائمة")
                moveTaskToBack(true)
            } else setStatus("تم رفض إذن التقاط الشاشة")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = AppSettings(this)
        val pad = dp(20)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "مترجم الألعاب الفوري"; textSize = 24f; gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "1) شغّل الخدمة\n2) افتح اللعبة\n3) اضغط ⛶ وحدد مربع الحوار\n4) اضغط ✔ ثم ▶ لبدء الترجمة"
            textSize = 16f; setPadding(0, pad, 0, pad)
        })
        statusView = TextView(this).apply { textSize = 14f; setPadding(0, 0, 0, dp(12)) }
        root.addView(statusView)
        root.addView(Button(this).apply { text = "تشغيل الخدمة"; setOnClickListener { startFlow() } })
        root.addView(Button(this).apply {
            text = "إيقاف الخدمة"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                setStatus("تم الإيقاف")
            }
        })

        buildSettings(root)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    // ------------------------------------------------------------ الإعدادات

    private fun buildSettings(root: LinearLayout) {
        root.addView(TextView(this).apply {
            text = "⚙ الإعدادات"; textSize = 20f; setPadding(0, dp(24), 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "تُطبَّق التغييرات على الحوار التالي مباشرة"; textSize = 12f
        })

        addSeek(root, "سرعة الفحص (أقل = أسرع)", " ms", 150, 1000,
            { settings.scanIntervalMs }, { settings.scanIntervalMs = it })
        addSeek(root, "فاصل إخفاء التغطية للفحص (أكبر = وميض أقل)", " ms", 500, 3000,
            { settings.peekIntervalMs }, { settings.peekIntervalMs = it })
        addSeek(root, "حجم خط الترجمة", "%", 60, 160,
            { settings.fontScalePercent }, { settings.fontScalePercent = it })
        addSeek(root, "شفافية الإطار (الحد 80 ليمر اللمس للعبة)", "%", 30, 80,
            { settings.maskOpacity }, { settings.maskOpacity = it })

        root.addView(TextView(this).apply { text = "ألوان الإطار والنص"; setPadding(0, dp(16), 0, dp(6)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        AppSettings.PRESETS.forEach { (name, bg, fg) ->
            row.addView(TextView(this).apply {
                text = "ع\n$name"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(fg)
                background = GradientDrawable().apply {
                    setColor(bg); cornerRadius = dp(10).toFloat(); setStroke(dp(1), 0xFF888888.toInt())
                }
                setPadding(dp(4), dp(8), dp(4), dp(8))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(dp(3), 0, dp(3), 0) }
                setOnClickListener {
                    settings.maskColor = bg; settings.textColor = fg
                    setStatus("تم اختيار: $name")
                }
            })
        }
        root.addView(row)

        root.addView(Switch(this).apply {
            text = "تحسين قراءة الخطوط الصغيرة (أبطأ)"
            isChecked = settings.sharpenSmallText
            setPadding(0, dp(16), 0, 0)
            setOnCheckedChangeListener { _, on -> settings.sharpenSmallText = on }
        })
    }

    private fun addSeek(
        parent: LinearLayout, title: String, unit: String, minV: Int, maxV: Int,
        get: () -> Int, set: (Int) -> Unit
    ) {
        val label = TextView(this).apply { setPadding(0, dp(16), 0, 0) }
        fun update(v: Int) { label.text = "$title: $v$unit" }
        update(get())
        val bar = SeekBar(this)
        bar.max = maxV - minV
        bar.progress = get().coerceIn(minV, maxV) - minV
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + minV
                update(v)
                if (fromUser) set(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(label); parent.addView(bar)
    }

    // ------------------------------------------------------------ الأذونات

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            overlayLauncher.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else requestNotifications()
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else requestProjection()
    }

    private fun requestProjection() {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    private fun setStatus(s: String) { statusView.text = s }
}
