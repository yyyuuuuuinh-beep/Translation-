package com.example.gametranslator

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * الشاشة الوحيدة في التطبيق: تطلب الأذونات بالترتيب ثم تشغّل الخدمة.
 * 1) إذن العرض فوق التطبيقات  2) إذن الإشعارات  3) إذن التقاط الشاشة
 */
class MainActivity : ComponentActivity() {

    private lateinit var statusView: TextView

    private val overlayLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) requestNotifications()
            else setStatus("لم يتم منح إذن العرض فوق التطبيقات")
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            requestProjection() // الإشعارات اختيارية، نكمل في كل الأحوال
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, res.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_DATA, data)
                }
                startForegroundService(intent)
                setStatus("الخدمة تعمل ✓ افتح اللعبة واستخدم الأزرار العائمة")
                moveTaskToBack(true)
            } else {
                setStatus("تم رفض إذن التقاط الشاشة")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "مترجم الألعاب الفوري"
            textSize = 24f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "1) شغّل الخدمة\n2) افتح اللعبة\n3) اضغط ⛶ وحدد مربع الحوار\n4) اضغط ✔ ثم ▶ لبدء الترجمة"
            textSize = 16f
            setPadding(0, pad, 0, pad)
        })
        statusView = TextView(this).apply { textSize = 14f; setPadding(0, 0, 0, pad) }
        root.addView(statusView)
        root.addView(Button(this).apply {
            text = "تشغيل الخدمة"
            setOnClickListener { startFlow() }
        })
        root.addView(Button(this).apply {
            text = "إيقاف الخدمة"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                setStatus("تم الإيقاف")
            }
        })
        setContentView(root)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            overlayLauncher.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else requestNotifications()
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else requestProjection()
    }

    private fun requestProjection() {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    private fun setStatus(s: String) { statusView.text = s }
}
