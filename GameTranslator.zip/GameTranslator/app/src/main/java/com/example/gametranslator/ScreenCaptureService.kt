package com.example.gametranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import androidx.core.content.IntentCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.nio.ByteBuffer
import kotlin.math.abs

/**
 * التدفق:
 *  لقطة الشاشة (ImageReader) -> اقتطاع منطقة الحوار -> توقيع (Hash مصغّر) ومقارنته بالسابق
 *  -> إن تغيّر ثم استقرّ لمدة STABLE_MS (انتهى تأثير الكتابة التدريجي) -> OCR -> ترجمة -> عرض.
 */
class ScreenCaptureService : Service(), FloatingOverlayManager.Listener {

    companion object {
        const val ACTION_START = "com.example.gametranslator.START"
        const val ACTION_STOP = "com.example.gametranslator.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "capture"
        private const val NOTIF_ID = 1
        private const val TAG = "GameTranslator"

        // ضبط الأداء
        private const val FRAME_INTERVAL_MS = 150L   // أقصى ~6 إطارات/ثانية يتم فحصها
        private const val STABLE_MS = 450L           // انتظار استقرار النص قبل OCR
        private const val SIG_COLS = 96              // شبكة العينات للمقارنة
        private const val SIG_ROWS = 36
        private const val PIXEL_DIFF = 40            // فرق السطوع الذي يُعدّ تغيّراً
        private const val MIN_CHANGED_POINTS = 2     // عدد النقاط المتغيرة لاعتبار الإطار مختلفاً
    }

    private lateinit var overlay: FloatingOverlayManager
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
    )

    @Volatile private var scanning = false
    @Volatile private var translatorReady = false
    @Volatile private var latestCrop: Bitmap? = null
    @Volatile private var ocrBusy = false

    // تُستخدم فقط من خيط captureHandler
    private var lastSig: IntArray? = null
    private var lastFrameTime = 0L

    // تُستخدم فقط من الـ Main
    private var lastSourceText = ""

    // ------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        captureThread = HandlerThread("capture").also { it.start() }
        captureHandler = Handler(captureThread.looper)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Screen translator", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> if (projection == null) startCapture(intent)
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        // يجب استدعاء startForeground قبل getMediaProjection (إلزامي منذ Android 14)
        startForegroundCompat()

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (data == null) { stopSelf(); return }

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mgr.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() } // المستخدم أنهى المشاركة من شريط الحالة
        }
        proj.registerCallback(projectionCallback!!, Handler(Looper.getMainLooper())) // إلزامي في Android 14+
        projection = proj

        overlay = FloatingOverlayManager(this, this).also { it.show() }
        setupCapture()
        prepareTranslator()
    }

    private fun startForegroundCompat() {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("مترجم الألعاب يعمل")
            .setContentText("اضغط إيقاف لإنهاء الخدمة")
            .addAction(0, "إيقاف", stopIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIF_ID, n)
    }

    /** ينشئ ImageReader + VirtualDisplay بحجم الشاشة الحالي (ويُعاد عند تدوير الشاشة). */
    private fun setupCapture() {
        val size = overlay.screenSize()
        val dpi = resources.displayMetrics.densityDpi
        val reader = ImageReader.newInstance(size.x, size.y, PixelFormat.RGBA_8888, 2)
        reader.setOnImageAvailableListener({ onFrame(it) }, captureHandler)

        val old = imageReader
        imageReader = reader
        val vd = virtualDisplay
        if (vd == null) {
            virtualDisplay = projection!!.createVirtualDisplay(
                "GameTranslatorCapture", size.x, size.y, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, captureHandler
            )
        } else {
            vd.resize(size.x, size.y, dpi)
            vd.surface = reader.surface
        }
        old?.close()
        captureHandler.post { lastSig = null }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (projection != null) setupCapture()
    }

    private fun prepareTranslator() {
        scope.launch {
            try {
                Toast.makeText(this@ScreenCaptureService, "جارٍ تجهيز نموذج الترجمة…", Toast.LENGTH_SHORT).show()
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                translatorReady = true
                Toast.makeText(this@ScreenCaptureService, "نموذج الترجمة جاهز ✓", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Log.e(TAG, "translator download failed", e)
                Toast.makeText(this@ScreenCaptureService, "فشل تنزيل نموذج الترجمة (تحقق من الإنترنت)", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------------------------------------------------- overlay callbacks

    override fun onScanStateChanged(scanning: Boolean) {
        this.scanning = scanning
        lastSourceText = ""
        captureHandler.removeCallbacks(ocrRunnable)
        captureHandler.post { lastSig = null }
    }

    override fun onCloseRequested() { stopSelf() }

    // ------------------------------------------------------------ frame loop

    /** يعمل على خيط captureThread. */
    private fun onFrame(reader: ImageReader) {
        val image = try { reader.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val now = SystemClock.uptimeMillis()
            if (!scanning || now - lastFrameTime < FRAME_INTERVAL_MS) return
            lastFrameTime = now

            val rect = clamp(overlay.getScanRect(), image.width, image.height) ?: return
            val plane = image.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride

            // 1) توقيع مصغّر للمنطقة (بدون نسخ الصورة كاملة)
            val sig = computeSignature(buf, rowStride, pixelStride, rect)
            val prev = lastSig
            if (prev != null && !hasChanged(prev, sig)) return
            lastSig = sig

            // 2) تغيّر فعلي => اقتطع المنطقة وأجّل OCR حتى يستقر النص
            latestCrop = cropRegion(buf, rowStride, pixelStride, rect)
            captureHandler.removeCallbacks(ocrRunnable)
            captureHandler.postDelayed(ocrRunnable, STABLE_MS)
        } finally {
            image.close()
        }
    }

    private val ocrRunnable = Runnable {
        val bmp = latestCrop ?: return@Runnable
        scope.launch { runPipeline(bmp) }
    }

    private fun clamp(r: Rect, w: Int, h: Int): Rect? {
        val c = Rect(maxOf(0, r.left), maxOf(0, r.top), minOf(w, r.right), minOf(h, r.bottom))
        return if (c.width() < 8 || c.height() < 8) null else c
    }

    private fun lum(buf: ByteBuffer, i: Int): Int =
        ((buf.get(i).toInt() and 0xFF) * 3 + (buf.get(i + 1).toInt() and 0xFF) * 6 +
                (buf.get(i + 2).toInt() and 0xFF)) / 10

    private fun computeSignature(buf: ByteBuffer, rowStride: Int, pixelStride: Int, r: Rect): IntArray {
        val sig = IntArray(SIG_COLS * SIG_ROWS)
        var k = 0
        for (j in 0 until SIG_ROWS) {
            val y = r.top + r.height() * j / SIG_ROWS
            for (i in 0 until SIG_COLS) {
                val x = r.left + r.width() * i / SIG_COLS
                sig[k++] = lum(buf, y * rowStride + x * pixelStride)
            }
        }
        return sig
    }

    private fun hasChanged(a: IntArray, b: IntArray): Boolean {
        var diff = 0
        for (i in a.indices) {
            if (abs(a[i] - b[i]) > PIXEL_DIFF && ++diff >= MIN_CHANGED_POINTS) return true
        }
        return false
    }

    /** ينسخ المنطقة المطلوبة فقط من الـ buffer (مع مراعاة rowStride) إلى Bitmap. */
    private fun cropRegion(buf: ByteBuffer, rowStride: Int, pixelStride: Int, r: Rect): Bitmap {
        val w = r.width(); val h = r.height()
        val rowBytes = w * pixelStride
        val out = ByteArray(rowBytes * h)
        for (row in 0 until h) {
            buf.position((r.top + row) * rowStride + r.left * pixelStride)
            buf.get(out, row * rowBytes, rowBytes)
        }
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also {
            it.copyPixelsFromBuffer(ByteBuffer.wrap(out))
        }
    }

    // ------------------------------------------------------- OCR + translate

    /** تعمل على الـ Main (مهام ML Kit غير متزامنة ولا تحجب الواجهة). */
    private suspend fun runPipeline(bmp: Bitmap) {
        if (ocrBusy) { captureHandler.postDelayed(ocrRunnable, 200); return }
        ocrBusy = true
        try {
            // تكبير بالأقرب (nearest) يحافظ على حدة خطوط البكسل ويحسّن دقة OCR
            val input = if (bmp.width < 900)
                Bitmap.createScaledBitmap(bmp, bmp.width * 2, bmp.height * 2, false) else bmp

            val result = recognizer.process(InputImage.fromBitmap(input, 0)).await()
            if (!scanning) return

            val text = result.text.replace(Regex("\\s+"), " ").trim()
            if (text.length < 2) {            // لا يوجد حوار => أخفِ الترجمة
                lastSourceText = ""
                overlay.showTranslation(null)
                return
            }
            if (text == lastSourceText) return
            if (!translatorReady) {
                overlay.showTranslation("جارٍ تجهيز نموذج الترجمة…")
                return
            }
            val arabic = translator.translate(text).await()
            lastSourceText = text
            if (scanning) overlay.showTranslation(arabic)
        } catch (e: Exception) {
            Log.e(TAG, "pipeline error", e)
        } finally {
            ocrBusy = false
        }
    }

    // ------------------------------------------------------------ cleanup

    override fun onDestroy() {
        scanning = false
        scope.cancel()
        if (::overlay.isInitialized) overlay.destroy()
        virtualDisplay?.release(); virtualDisplay = null
        imageReader?.close(); imageReader = null
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop(); projection = null
        recognizer.close()
        translator.close()
        captureThread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
