package com.example.gametranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import androidx.core.content.IntentCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.android.asCoroutineDispatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.nio.ByteBuffer
import kotlin.math.abs

/**
 * آلة حالات تعمل كلها على خيط واحد (captureThread) => لا حاجة لأقفال:
 *
 *  IDLE    : لا توجد تغطية. كل 300ms تُقارن بصمة مصغّرة لمنطقة الحوار؛ عند التغيّر ثم الاستقرار => OCR.
 *  SHOWING : التغطية ظاهرة (النص الأصلي مخفي تحتها فلا يمكن رؤية تغيّره). نفحص التغيير بـ "نظرة خاطفة":
 *            بعد كل ضغطة (250ms) وكل PEEK_INTERVAL_MS نخفي التغطية ~100ms ونقارن البصمة بالأصلية.
 *  PEEKING : التغطية مخفية لحظياً لالتقاط إطار نظيف.
 *
 *  OCR (ML Kit) -> TextBlocks مع Bounding Boxes -> ترجمة كل كتلة (ML Kit على الجهاز + ذاكرة مؤقتة)
 *  -> overlay.showMasks(): مستطيل أسود + نص عربي في نفس مكان النص الأصلي.
 */
class ScreenCaptureService : Service(), FloatingOverlayManager.Listener {

    companion object {
        const val ACTION_START = "com.example.gametranslator.START"
        const val ACTION_STOP = "com.example.gametranslator.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "capture"
        private const val NOTIF_ID = 1
        private const val TAG = "GameTranslator"

        // ===== ضبط السرعة والحساسية =====
        private const val STABLE_MS = 300L            // استقرار النص قبل OCR (تأثير الكتابة التدريجية)
        private const val PEEK_SETTLE_MS = 90L        // انتظار اختفاء التغطية قبل أخذ الإطار
        private const val TAP_PEEK_DELAY_MS = 250L    // بعد الضغطة بكم نفحص الحوار
        private const val SIG_COLS = 96
        private const val SIG_ROWS = 36
        private const val PIXEL_DIFF = 40
        private const val MIN_CHANGED_POINTS = 2
        private const val CACHE_MAX = 400
    }

    private enum class Phase { IDLE, SHOWING, PEEKING }

    private lateinit var overlay: FloatingOverlayManager
    private lateinit var settings: AppSettings   // دورة الفحص/الوميض/تحسين الخط من شاشة الإعدادات
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler
    private lateinit var scope: CoroutineScope                         // على خيط الالتقاط
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
    )
    private val spaces = Regex("\\s+")

    @Volatile private var scanning = false
    @Volatile private var translatorReady = false

    // ---- حالة (خيط captureThread فقط) ----
    private var phase = Phase.IDLE
    private var latestImage: Image? = null
    private var frameCounter = 0L
    private var lastSig: IntArray? = null
    private var baselineSig: IntArray? = null
    private var changePending = false
    private var changeTime = 0L
    private var changeGen = 0
    private var ocrRunning = false
    private var showingSince = 0L
    private var peekStartFrame = 0L
    private var peekTries = 0
    private val cache = HashMap<String, String>()

    // ------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(this)
        captureThread = HandlerThread("capture").also { it.start() }
        captureHandler = Handler(captureThread.looper)
        scope = CoroutineScope(SupervisorJob() + captureHandler.asCoroutineDispatcher())
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Screen translator", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> if (projection == null) startCapture(intent)
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        startForegroundCompat() // قبل getMediaProjection (إلزامي منذ Android 14)

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (data == null) { stopSelf(); return }

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mgr.getMediaProjection(resultCode, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }
        proj.registerCallback(projectionCallback!!, Handler(Looper.getMainLooper()))
        projection = proj

        overlay = FloatingOverlayManager(this, this).also { it.show() }
        setupCapture()
        prepareTranslator()
    }

    private fun startForegroundCompat() {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("مترجم الألعاب يعمل")
            .setContentText("اضغط إيقاف لإنهاء الخدمة")
            .addAction(0, "إيقاف", stopIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIF_ID, n)
    }

    /** ImageReader + VirtualDisplay بحجم الشاشة الحالي (ويُعاد عند التدوير). */
    private fun setupCapture() {
        val size = overlay.screenSize()
        val dpi = resources.displayMetrics.densityDpi
        val reader = ImageReader.newInstance(size.x, size.y, PixelFormat.RGBA_8888, 3)
        reader.setOnImageAvailableListener({ onFrame(it) }, captureHandler)

        val old = imageReader
        imageReader = reader
        val vd = virtualDisplay
        if (vd == null) {
            virtualDisplay = projection!!.createVirtualDisplay(
                "GameTranslatorCapture", size.x, size.y, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, captureHandler
            )
        } else {
            vd.resize(size.x, size.y, dpi)
            vd.surface = reader.surface
        }
        captureHandler.post {
            latestImage?.close(); latestImage = null
            old?.close()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (projection != null) {
            setupCapture()
            overlay.onScreenChanged()
            captureHandler.post { resetState() }
        }
    }

    private fun prepareTranslator() {
        mainScope.launch {
            try {
                Toast.makeText(this@ScreenCaptureService, "جارٍ تجهيز نموذج الترجمة…", Toast.LENGTH_SHORT).show()
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                translatorReady = true
                captureHandler.post { lastSig = null } // أعد المحاولة للنص الحالي
                Toast.makeText(this@ScreenCaptureService, "نموذج الترجمة جاهز ✓", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "translator download failed", e)
                Toast.makeText(this@ScreenCaptureService, "فشل تنزيل نموذج الترجمة (تحقق من الإنترنت)", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------------------------------------------------- overlay callbacks

    override fun onScanStateChanged(scanning: Boolean) {
        this.scanning = scanning
        captureHandler.removeCallbacks(tickRunnable)
        captureHandler.post {
            resetState()
            if (scanning) captureHandler.post(tickRunnable)
        }
    }

    override fun onCloseRequested() { stopSelf() }

    /** ضغطة في اللعبة: إن كانت التغطية ظاهرة افحص الحوار بعد لحظة. */
    override fun onUserTap() {
        captureHandler.postDelayed({
            if (scanning && phase == Phase.SHOWING) startPeek()
        }, TAP_PEEK_DELAY_MS)
    }

    private fun resetState() {
        phase = Phase.IDLE
        lastSig = null; baselineSig = null
        changePending = false
        changeGen++
        captureHandler.removeCallbacks(peekRunnable)
    }

    // ------------------------------------------------------------ frames

    /** خيط captureThread: نحتفظ بأحدث إطار فقط. */
    private fun onFrame(reader: ImageReader) {
        val img = try { reader.acquireLatestImage() } catch (e: Exception) { null } ?: return
        latestImage?.close()
        latestImage = img
        frameCounter++
    }

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!scanning) return
            try { tick() } catch (e: Exception) { Log.e(TAG, "tick error", e) }
            captureHandler.postDelayed(this, settings.scanIntervalMs.toLong())
        }
    }

    private fun tick() {
        val img = latestImage ?: return
        val now = SystemClock.uptimeMillis()
        val rect = clamp(overlay.getScanRect(), img.width, img.height) ?: return

        when (phase) {
            Phase.IDLE -> {
                val sig = sigOf(img, rect)
                val prev = lastSig
                if (prev == null || hasChanged(prev, sig)) {
                    lastSig = sig
                    changePending = true
                    changeTime = now
                    changeGen++
                }
                if (changePending && !ocrRunning && now - changeTime >= STABLE_MS) {
                    changePending = false
                    startOcr(img, rect, sig)
                }
            }
            Phase.SHOWING -> if (now - showingSince >= settings.peekIntervalMs) startPeek()
            Phase.PEEKING -> Unit
        }
    }

    // ------------------------------------------------------------ peek

    private fun startPeek() {
        phase = Phase.PEEKING
        peekStartFrame = frameCounter
        peekTries = 0
        overlay.setMasksVisible(false)
        captureHandler.postDelayed(peekRunnable, PEEK_SETTLE_MS)
    }

    private val peekRunnable = object : Runnable {
        override fun run() {
            if (!scanning || phase != Phase.PEEKING) return
            val now = SystemClock.uptimeMillis()

            // لم يصل إطار جديد بعد إخفاء التغطية؟ انتظر قليلاً ثم استسلم
            if (frameCounter == peekStartFrame) {
                if (peekTries++ < 4) { captureHandler.postDelayed(this, 40); return }
                restoreMasks(now); return
            }
            val img = latestImage
            val rect = img?.let { clamp(overlay.getScanRect(), it.width, it.height) }
            if (img == null || rect == null) { restoreMasks(now); return }

            val sig = sigOf(img, rect)
            val base = baselineSig
            if (base != null && !hasChanged(base, sig)) {
                restoreMasks(now)                       // نفس الحوار: أعد التغطية
            } else {
                lastSig = sig                           // حوار جديد: تبقى التغطية مخفية ونعيد OCR
                changePending = true
                changeTime = now
                changeGen++
                phase = Phase.IDLE
            }
        }
    }

    private fun restoreMasks(now: Long) {
        overlay.setMasksVisible(true)
        showingSince = now
        phase = Phase.SHOWING
    }

    // ------------------------------------------------------------ OCR + translate

    private fun startOcr(img: Image, rect: Rect, sig: IntArray) {
        val p = img.planes[0]
        val bmp = cropRegion(p.buffer, p.rowStride, p.pixelStride, rect)
        val gen = changeGen
        ocrRunning = true
        scope.launch {
            try {
                val items = recognizeAndTranslate(bmp, rect)
                if (!scanning || gen != changeGen) return@launch   // تغيّر الحوار أثناء المعالجة => تجاهل
                if (items.isEmpty()) {
                    overlay.clearMasks()
                    phase = Phase.IDLE
                } else {
                    overlay.showMasks(items)
                    baselineSig = sig
                    showingSince = SystemClock.uptimeMillis()
                    phase = Phase.SHOWING
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "ocr error", e)
            } finally {
                ocrRunning = false
            }
        }
    }

    private suspend fun recognizeAndTranslate(bmp: Bitmap, roi: Rect): List<MaskItem> {
        val s = if (settings.sharpenSmallText) 2 else 1
        val input = if (s > 1) Bitmap.createScaledBitmap(bmp, bmp.width * s, bmp.height * s, false) else bmp
        val result = recognizer.process(InputImage.fromBitmap(input, 0)).await()

        val blocks = result.textBlocks.filter { b ->
            b.boundingBox != null && b.text.count { it.isLetter() } >= 2
        }
        if (blocks.isEmpty() || !translatorReady) return emptyList()

        return coroutineScope {
            blocks.map { b ->
                async {
                    val bb = b.boundingBox!!
                    val src = spaces.replace(b.text, " ").trim()
                    MaskItem(
                        Rect(roi.left + bb.left / s, roi.top + bb.top / s,
                            roi.left + bb.right / s, roi.top + bb.bottom / s),
                        translateCached(src),
                        b.lines.size
                    )
                }
            }.awaitAll()
        }
    }

    private suspend fun translateCached(src: String): String {
        cache[src]?.let { return it }
        val ar = translator.translate(src).await()
        if (cache.size >= CACHE_MAX) cache.clear()
        cache[src] = ar
        return ar
    }

    // ------------------------------------------------------------ pixels

    private fun clamp(r: Rect, w: Int, h: Int): Rect? {
        val c = Rect(maxOf(0, r.left), maxOf(0, r.top), minOf(w, r.right), minOf(h, r.bottom))
        return if (c.width() < 8 || c.height() < 8) null else c
    }

    private fun sigOf(img: Image, r: Rect): IntArray {
        val p = img.planes[0]
        return computeSignature(p.buffer, p.rowStride, p.pixelStride, r)
    }

    private fun lum(buf: ByteBuffer, i: Int): Int =
        ((buf.get(i).toInt() and 0xFF) * 3 + (buf.get(i + 1).toInt() and 0xFF) * 6 +
                (buf.get(i + 2).toInt() and 0xFF)) / 10

    /** بصمة مصغّرة (عيّنات سطوع) بدون نسخ الصورة. */
    private fun computeSignature(buf: ByteBuffer, rowStride: Int, pixelStride: Int, r: Rect): IntArray {
        val sig = IntArray(SIG_COLS * SIG_ROWS)
        var k = 0
        for (j in 0 until SIG_ROWS) {
            val y = r.top + r.height() * j / SIG_ROWS
            for (i in 0 until SIG_COLS) {
                val x = r.left + r.width() * i / SIG_COLS
                sig[k++] = lum(buf, y * rowStride + x * pixelStride)
            }
        }
        return sig
    }

    private fun hasChanged(a: IntArray, b: IntArray): Boolean {
        var diff = 0
        for (i in a.indices) {
            if (abs(a[i] - b[i]) > PIXEL_DIFF && ++diff >= MIN_CHANGED_POINTS) return true
        }
        return false
    }

    private fun cropRegion(buf: ByteBuffer, rowStride: Int, pixelStride: Int, r: Rect): Bitmap {
        val w = r.width(); val h = r.height()
        val rowBytes = w * pixelStride
        val out = ByteArray(rowBytes * h)
        for (row in 0 until h) {
            buf.position((r.top + row) * rowStride + r.left * pixelStride)
            buf.get(out, row * rowBytes, rowBytes)
        }
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also {
            it.copyPixelsFromBuffer(ByteBuffer.wrap(out))
        }
    }

    // ------------------------------------------------------------ cleanup

    override fun onDestroy() {
        scanning = false
        scope.cancel()
        mainScope.cancel()
        if (::overlay.isInitialized) overlay.destroy()
        captureHandler.removeCallbacksAndMessages(null)
        captureHandler.post { latestImage?.close(); latestImage = null }
        virtualDisplay?.release(); virtualDisplay = null
        imageReader?.close(); imageReader = null
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop(); projection = null
        recognizer.close()
        translator.close()
        captureThread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
