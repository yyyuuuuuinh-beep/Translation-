package com.example.gametranslator

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/** قطعة نص مرصودة: مكانها على الشاشة + الترجمة العربية + عدد أسطرها الأصلية. */
data class MaskItem(val rect: Rect, val text: String, val lines: Int, val src: String = "")

/**
 * النوافذ العائمة:
 *  1) لوحة التحكم (قابلة للمس): ✥ سحب | ▶/⏹ تشغيل | ⛶ ضبط المربع | ✕ إغلاق
 *  2) مربع تحديد منطقة الحوار (يظهر أثناء الضبط فقط)
 *  3) نافذة التغطية (Mask): بملء الشاشة، FLAG_NOT_TOUCHABLE، ترسم مستطيلاً أسود فوق كل نص
 *     إنجليزي ثم الترجمة العربية فوقه في نفس المكان.
 *  4) مراقب لمس 1×1 بكسل (WATCH_OUTSIDE_TOUCH) يُعلم الخدمة بأي ضغطة لتفحص تغيّر الحوار فوراً.
 */
class FloatingOverlayManager(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onScanStateChanged(scanning: Boolean)
        fun onCloseRequested()
        fun onUserTap()
    }

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = context.getSharedPreferences("overlay", Context.MODE_PRIVATE)
    private val density = context.resources.displayMetrics.density
    private val main = Handler(Looper.getMainLooper())
    private val settings = AppSettings(context)
    private fun dp(v: Int) = (v * density).toInt()
    private fun dpf(v: Float) = v * density

    private var panel: LinearLayout? = null
    private lateinit var toggleBtn: TextView
    private lateinit var editBtn: TextView
    private var statusTv: TextView? = null

    /** وقت آخر رسم فعلي للتغطية (تستخدمه الخدمة لمعرفة متى صارت ظاهرة في الالتقاط). */
    @Volatile var lastMaskDrawAt = 0L

    private var boxView: BoxView? = null

    private var maskView: MaskView? = null
    private var maskParams: WindowManager.LayoutParams? = null

    private var tapView: View? = null

    @Volatile private var scanRect: Rect = loadRect()
    private var isScanning = false
    private var isEditing = false

    // ---------------------------------------------------------------- helpers

    private val baseFlags = FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS

    private fun newParams(w: Int, h: Int, flags: Int) =
        WindowManager.LayoutParams(w, h, TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

    private fun round(color: Int, radius: Float) =
        GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = radius; setColor(color) }

    fun screenSize(): Point =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            @Suppress("DEPRECATION")
            Point().also { wm.defaultDisplay.getRealSize(it) }
        }

    fun getScanRect(): Rect = Rect(scanRect)

    /** المنطقة تُحفظ كنسب من الشاشة لكل اتجاه (أفقي/عمودي) فلا تخرج عن الشاشة عند التدوير. */
    private fun orientKey(s: Point) = if (s.x > s.y) "l" else "p"

    private fun loadRect(): Rect {
        val s = screenSize()
        val k = orientKey(s)
        val fx = prefs.getFloat("fx_$k", 0.05f).coerceIn(0f, 0.9f)
        val fy = prefs.getFloat("fy_$k", 0.65f).coerceIn(0f, 0.9f)
        val fw = prefs.getFloat("fw_$k", 0.90f).coerceIn(0.1f, 1f - fx)
        val fh = prefs.getFloat("fh_$k", 0.30f).coerceIn(0.1f, 1f - fy)
        return Rect((fx * s.x).toInt(), (fy * s.y).toInt(), ((fx + fw) * s.x).toInt(), ((fy + fh) * s.y).toInt())
    }

    private fun saveRect(r: Rect) {
        scanRect = Rect(r)
        val s = screenSize(); val k = orientKey(s)
        prefs.edit()
            .putFloat("fx_$k", r.left / s.x.toFloat()).putFloat("fy_$k", r.top / s.y.toFloat())
            .putFloat("fw_$k", r.width() / s.x.toFloat()).putFloat("fh_$k", r.height() / s.y.toFloat())
            .apply()
    }

    // ------------------------------------------------------------ show / panel

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        addMaskWindow()

        fun btn(label: String) = TextView(context).apply {
            text = label
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        }
        val handle = btn("✥")
        toggleBtn = btn("▶")
        editBtn = btn("⛶")
        val closeBtn = btn("✕")

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(0xCC202020.toInt(), dp(26).toFloat())
            setPadding(dp(6), dp(6), dp(6), dp(6))
            addView(handle); addView(toggleBtn); addView(editBtn); addView(closeBtn)
        }
        val status = TextView(context).apply {
            textSize = 11f
            setTextColor(Color.WHITE)
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            background = round(0xCC202020.toInt(), dp(10).toFloat())
            setPadding(dp(8), dp(4), dp(8), dp(4))
            maxWidth = dp(280)
            visibility = View.GONE
        }
        statusTv = status
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(row); addView(status)
        }
        val p = newParams(WRAP_CONTENT, WRAP_CONTENT, baseFlags or FLAG_NOT_TOUCH_MODAL).apply {
            x = dp(8); y = dp(80)
        }

        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = ox + (e.rawX - sx).toInt()
                        p.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(root, p)
                    }
                }
                return true
            }
        })
        toggleBtn.setOnClickListener { setScanning(!isScanning) }
        editBtn.setOnClickListener { if (isEditing) finishEditing() else startEditing() }
        closeBtn.setOnClickListener { listener.onCloseRequested() }

        panel = root
        wm.addView(root, p)
    }

    /** تبديل تشغيل/إيقاف مؤقت من خارج الواجهة (مثل أزرار الإشعار). */
    fun toggleScanning() { main.post { if (panel != null) setScanning(!isScanning) } }

    private fun setScanning(on: Boolean) {
        if (on && isEditing) finishEditing()
        if (on) scanRect = loadRect()
        isScanning = on
        toggleBtn.text = if (on) "⏸" else "▶"
        toggleBtn.setTextColor(if (on) Color.parseColor("#66FF66") else Color.WHITE)
        if (on) addTapWatcher() else { removeTapWatcher(); clearMasks() }
        listener.onScanStateChanged(on)
    }

    // ------------------------------------------------------------ box editor

    private fun startEditing() {
        if (isScanning) setScanning(false)
        scanRect = loadRect()
        val r = scanRect
        val p = newParams(r.width(), r.height(), baseFlags or FLAG_NOT_TOUCH_MODAL).apply {
            x = r.left; y = r.top
        }
        val v = BoxView(context, p)
        boxView = v
        wm.addView(v, p)
        isEditing = true
        editBtn.text = "✔"
    }

    private fun finishEditing() {
        boxView?.let { runCatching { wm.removeView(it) } }
        boxView = null
        isEditing = false
        if (::editBtn.isInitialized) editBtn.text = "⛶"
    }

    @SuppressLint("ViewConstructor")
    private inner class BoxView(ctx: Context, private val p: WindowManager.LayoutParams) : View(ctx) {
        private val handleSize = dp(44)
        private val minSize = dp(80)
        private val fill = Paint().apply { color = 0x3300AAFF }
        private val stroke = Paint().apply {
            color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = dp(3).toFloat()
        }
        private val solid = Paint().apply { color = Color.YELLOW }
        private val label = Paint().apply { color = Color.WHITE; textSize = dp(14).toFloat() }
        private var lastX = 0f; private var lastY = 0f
        private var resizing = false

        override fun onDraw(c: Canvas) {
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), stroke)
            c.drawRect(width - handleSize.toFloat(), height - handleSize.toFloat(),
                width.toFloat(), height.toFloat(), solid)
            c.drawText("Dialogue Scan Box", dp(8).toFloat(), dp(20).toFloat(), label)
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(e: MotionEvent): Boolean {
            val screen = screenSize()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.rawX; lastY = e.rawY
                    resizing = e.x > width - handleSize && e.y > height - handleSize
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - lastX).toInt(); val dy = (e.rawY - lastY).toInt()
                    lastX = e.rawX; lastY = e.rawY
                    if (resizing) {
                        p.width = min(max(minSize, p.width + dx), screen.x - p.x)
                        p.height = min(max(minSize, p.height + dy), screen.y - p.y)
                    } else {
                        p.x = min(max(0, p.x + dx), screen.x - p.width)
                        p.y = min(max(0, p.y + dy), screen.y - p.height)
                    }
                    wm.updateViewLayout(this, p)
                    scanRect = Rect(p.x, p.y, p.x + p.width, p.y + p.height)
                }
                MotionEvent.ACTION_UP -> saveRect(Rect(p.x, p.y, p.x + p.width, p.y + p.height))
            }
            return true
        }
    }

    // ------------------------------------------------------- mask (in-place) window

    private fun addMaskWindow() {
        val s = screenSize()
        val v = MaskView(context)
        // FLAG_NOT_TOUCHABLE: اللمس ينفذ إلى اللعبة.
        // alpha = 0.8: شرط أندرويد 12+ كي لا يمنع النظام اللمس العابر عبر النوافذ العائمة (الحد 0.8).
        val p = newParams(1, 1, baseFlags or FLAG_NOT_TOUCHABLE).apply {
            x = 0; y = 0; alpha = 0.5f
        }
        maskView = v; maskParams = p
        wm.addView(v, p)
    }

    /**
     * يعرض الإطار + الترجمة (آمنة للاستدعاء من أي خيط).
     * شفافية <= 80%: نافذة بملء الشاشة (اللمس يمرّ للعبة). فوق 80%: النافذة بحجم مناطق النص فقط.
     */
    fun showMasks(items: List<MaskItem>) {
        main.post {
            val v = maskView ?: return@post
            val p = maskParams ?: return@post
            v.setItems(items)
            if (items.isEmpty()) { idleMaskWindowNow(); return@post }
            val op = settings.maskOpacity
            val s = screenSize()
            if (op <= 80) {
                p.x = 0; p.y = 0; p.width = s.x; p.height = s.y
                v.setOrigin(0, 0)
            } else {
                val u = v.unionBounds() ?: Rect(0, 0, s.x, s.y)
                u.intersect(0, 0, s.x, s.y)
                p.x = u.left; p.y = u.top
                p.width = max(1, u.width()); p.height = max(1, u.height())
                v.setOrigin(u.left, u.top)
            }
            p.alpha = op / 100f
            runCatching { wm.updateViewLayout(v, p) }
        }
    }

    /** نافذة التغطية الخاملة: 1×1 وشفافية 0.5 فلا تحجب أي لمس. (على الـ Main فقط) */
    private fun idleMaskWindowNow() {
        val v = maskView ?: return
        val p = maskParams ?: return
        p.x = 0; p.y = 0; p.width = 1; p.height = 1; p.alpha = 0.5f
        v.setOrigin(0, 0)
        runCatching { wm.updateViewLayout(v, p) }
    }

    /** إخفاء مؤقت (يُستخدم لالتقاط الشاشة بدون التغطية). */
    fun setMasksVisible(visible: Boolean) {
        main.post {
            maskView?.visibility = if (visible) View.VISIBLE else View.INVISIBLE
            if (!visible) idleMaskWindowNow()
        }
    }

    /** رسالة حالة صغيرة تحت الأزرار (للتشخيص). null = إخفاء. */
    fun setStatus(text: String?) {
        main.post {
            val tv = statusTv ?: return@post
            if (text.isNullOrBlank()) { tv.visibility = View.GONE }
            else { if (tv.text.toString() != text) tv.text = text; tv.visibility = View.VISIBLE }
        }
    }

    fun clearMasks() {
        main.post { maskView?.setItems(emptyList()); idleMaskWindowNow() }
    }

    /** عند تدوير الشاشة. */
    fun onScreenChanged() {
        main.post {
            scanRect = loadRect()
            maskView?.setItems(emptyList())
            idleMaskWindowNow()
        }
    }

    private inner class MaskView(ctx: Context) : View(ctx) {
        private inner class Drawn(val box: Rect, val layout: StaticLayout, val textLeft: Int, val textTop: Int)

        private var drawn: List<Drawn> = emptyList()
        private var originX = 0
        private var originY = 0
        fun setOrigin(x: Int, y: Int) { originX = x; originY = y }
        fun unionBounds(): Rect? {
            if (drawn.isEmpty()) return null
            val u = Rect(drawn[0].box)
            for (d in drawn) u.union(d.box)
            return u
        }
        private val bg = Paint()

        fun setItems(items: List<MaskItem>) {
            bg.color = settings.maskColor
            drawn = items.map { build(it) }
            visibility = View.VISIBLE
            invalidate()
        }

        private fun build(item: MaskItem): Drawn {
            val pad = dp(6)
            val box = Rect(item.rect).apply { inset(-pad, -pad) }
            val textW = max(dp(20), item.rect.width())
            val maxH = item.rect.height()

            // حجم الخط: يبدأ من ارتفاع السطر الأصلي ثم يصغر حتى تتسع الترجمة داخل الإطار
            val lineH = item.rect.height().toFloat() / max(1, item.lines)
            val fs = settings.fontScalePercent / 100f
            var size = (lineH * 0.8f * fs).coerceIn(dpf(10f) * fs, dpf(26f) * fs)
            val minSize = dpf(9f)
            var layout: StaticLayout
            while (true) {
                val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = settings.textColor; textSize = size; typeface = Typeface.DEFAULT_BOLD }
                layout = StaticLayout.Builder.obtain(item.text, 0, item.text.length, paint, textW)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setIncludePad(false)
                    .build()
                if (layout.height <= maxH || size <= minSize) break
                size -= density
            }
            // إن لم تتسع الترجمة حتى بأصغر خط، يتمدد الإطار الأسود للأسفل
            if (layout.height > maxH) box.bottom = box.top + layout.height + 2 * pad
            val top = box.top + pad + max(0, (box.height() - 2 * pad - layout.height) / 2)
            return Drawn(box, layout, box.left + pad, top)
        }

        override fun onDraw(c: Canvas) {
            if (drawn.isNotEmpty()) lastMaskDrawAt = SystemClock.uptimeMillis()
            c.translate(-originX.toFloat(), -originY.toFloat())
            val r = dpf(6f)
            for (d in drawn) {
                c.drawRoundRect(RectF(d.box), r, r, bg)
                c.save()
                c.translate(d.textLeft.toFloat(), d.textTop.toFloat())
                d.layout.draw(c)
                c.restore()
            }
        }
    }

    // -------------------------------------------------------------- tap watcher

    /** نافذة 1×1 تستقبل ACTION_OUTSIDE عند أي لمسة في اللعبة (بدون إحداثيات) => فحص فوري للتغيير. */
    @SuppressLint("ClickableViewAccessibility")
    private fun addTapWatcher() {
        if (tapView != null) return
        val v = View(context).apply {
            setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) listener.onUserTap()
                false
            }
        }
        val p = newParams(1, 1, FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCH_MODAL or
                FLAG_WATCH_OUTSIDE_TOUCH or FLAG_LAYOUT_NO_LIMITS)
        wm.addView(v, p)
        tapView = v
    }

    private fun removeTapWatcher() {
        tapView?.let { runCatching { wm.removeView(it) } }
        tapView = null
    }

    fun destroy() {
        removeTapWatcher()
        finishEditing()
        maskView?.let { runCatching { wm.removeView(it) } }
        maskView = null
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }
}
