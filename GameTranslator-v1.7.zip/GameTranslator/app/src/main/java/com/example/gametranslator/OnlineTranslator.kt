package com.example.gametranslator

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * ترجمة إنجليزي -> عربي عبر الإنترنت (بدون مكتبات إضافية). جودتها أعلى في ترجمة الجُمل والسياق.
 * يجب استدعاؤها من خيط خلفي (Dispatchers.IO).
 */
object OnlineTranslator {

    private fun fetchParts(text: String, timeoutMs: Int): JSONArray {
        val q = URLEncoder.encode(text, "UTF-8")
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=$q")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val body = c.inputStream.bufferedReader().use { it.readText() }
            return JSONArray(body).getJSONArray(0)
        } finally {
            c.disconnect()
        }
    }

    fun translate(text: String, timeoutMs: Int = 3000): String {
        val parts = fetchParts(text, timeoutMs)
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONArray(i).optString(0, ""))
        val out = sb.toString().trim()
        if (out.isEmpty()) throw IllegalStateException("رد فارغ")
        return out
    }

    /**
     * ترجمة بالسياق: نرسل الحوار السابق + الحالي معاً ليفهم المترجم الضمائر وتكملة الجمل،
     * ثم نقتطع ترجمة الجزء الحالي فقط (بمطابقة الجمل الأصلية). عند أي خلل نعود لترجمة الجزء الحالي وحده.
     */
    fun translateWithContext(context: String, text: String, timeoutMs: Int = 3000): String {
        val ctx = context.trim()
        if (ctx.isEmpty() || ctx.length > 300 || ctx == text.trim()) return translate(text, timeoutMs)

        fun compact(s: String) = s.count { !it.isWhitespace() }
        val parts = fetchParts("$ctx\n$text", timeoutMs)
        val ctxLen = compact(ctx)
        var cum = 0
        var aligned = false
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val seg = parts.getJSONArray(i)
            if (!aligned) {
                cum += compact(seg.optString(1, ""))
                if (cum == ctxLen) aligned = true       // انتهت جمل السياق
                else if (cum > ctxLen) break            // جملة تجاوزت الحد: المطابقة فشلت
                continue
            }
            sb.append(seg.optString(0, ""))
        }
        val out = sb.toString().trim()
        return if (aligned && out.isNotEmpty()) out else translate(text, timeoutMs)
    }
}
