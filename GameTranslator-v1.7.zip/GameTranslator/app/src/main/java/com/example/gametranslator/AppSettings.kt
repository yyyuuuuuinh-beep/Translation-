package com.example.gametranslator

import android.content.Context

/** إعدادات المستخدم (SharedPreferences). تُقرأ عند الاستخدام فتُطبَّق على الحوار التالي مباشرة. */
class AppSettings(context: Context) {
    private val p = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** دورة الفحص (ms): أقل = أسرع وأثقل. */
    var scanIntervalMs: Int
        get() = p.getInt("scan", 150)
        set(v) { p.edit().putInt("scan", v).apply() }

    /** حساسية كشف تغيّر النص (1..10): أعلى = يلتقط التغيّر الصغير لكن قد يخطئ مع حركة الخلفية. */
    var changeSensitivity: Int
        get() = p.getInt("sens", 5).coerceIn(1, 10)
        set(v) { p.edit().putInt("sens", v).apply() }

    /** جودة الالتقاط (% من دقة الشاشة): أقل = أسرع بكثير. يُطبَّق عند إعادة تشغيل الخدمة. */
    var captureScalePercent: Int
        get() = p.getInt("capscale", 100).coerceIn(40, 100)
        set(v) { p.edit().putInt("capscale", v).apply() }

    /** حجم خط الترجمة (% من الحجم التلقائي). */
    var fontScalePercent: Int
        get() = p.getInt("font", 100)
        set(v) { p.edit().putInt("font", v).apply() }

    /** شفافية التغطية (%). فوق 80 = تغطية كاملة، لكن أندرويد 12+ قد يحجب اللمس داخل مربع النص فقط. */
    var maskOpacity: Int
        get() = p.getInt("opacity", 80).coerceIn(30, 100)
        set(v) { p.edit().putInt("opacity", v.coerceIn(30, 100)).apply() }

    var maskColor: Int
        get() = p.getInt("maskColor", PRESETS[0].second)
        set(v) { p.edit().putInt("maskColor", v).apply() }

    var textColor: Int
        get() = p.getInt("textColor", PRESETS[0].third)
        set(v) { p.edit().putInt("textColor", v).apply() }

    /** تكبير الصورة 2× قبل OCR لتحسين قراءة الخطوط الصغيرة (أبطأ). */
    var sharpenSmallText: Boolean
        get() = p.getBoolean("sharpen", false)
        set(v) { p.edit().putBoolean("sharpen", v).apply() }

    /** true = ترجمة الجهاز (ML Kit) أولاً: أسرع؛ false = ترجمة الإنترنت أولاً: أدق في السياق. */
    var preferOnDevice: Boolean
        get() = p.getBoolean("ondevice", false)
        set(v) { p.edit().putBoolean("ondevice", v).apply() }

    /** فحص دائم: يعيد قراءة المربع كل ~0.5 ثانية حتى لو لم تتغير الشاشة (ما دام لا توجد تغطية ظاهرة). */
    var alwaysScan: Boolean
        get() = p.getBoolean("always", true)
        set(v) { p.edit().putBoolean("always", v).apply() }

    companion object {
        /** (الاسم، لون الإطار، لون النص) */
        val PRESETS = listOf(
            Triple("أسود / أبيض", 0xFF000000.toInt(), 0xFFFFFFFF.toInt()),
            Triple("رمادي / أبيض", 0xFF303030.toInt(), 0xFFFFFFFF.toInt()),
            Triple("كحلي / أصفر", 0xFF0B1F4D.toInt(), 0xFFFFE066.toInt()),
            Triple("بيج / أسود", 0xFFF2E3B8.toInt(), 0xFF000000.toInt())
        )
    }
}
