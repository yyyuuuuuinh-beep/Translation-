package com.example.gametranslator

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * ترجمة إنجليزي -> عربي عبر الإنترنت (بدون مكتبات إضافية). تُستخدم كبديل فوري
 * عندما لا يكون نموذج ML Kit للترجمة جاهزاً بعد، وفي زر "اختبار الترجمة".
 * ملاحظة: يجب استدعاؤها من خيط خلفي (Dispatchers.IO).
 */
object OnlineTranslator {
    fun translate(text: String, timeoutMs: Int = 4000): String {
        val q = URLEncoder.encode(text, "UTF-8")
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=$q")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val parts = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONArray(i).optString(0, ""))
            val out = sb.toString().trim()
            if (out.isEmpty()) throw IllegalStateException("رد فارغ")
            return out
        } finally {
            c.disconnect()
        }
    }
}
