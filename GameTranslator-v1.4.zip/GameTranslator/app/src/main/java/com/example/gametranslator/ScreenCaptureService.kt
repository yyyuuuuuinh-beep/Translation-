package com.example.gametranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import androidx.core.content.IntentCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.android.asCoroutineDispatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * v1.3 — الفكرة: التغطية تبقى ثابتة ولا تُخفى إلا إذا تغيّر النص الأصلي فعلاً.
 *
 * كيف نكشف التغيّر والتغطية ظاهرة؟ نافذة التغطية شفافيتها 0.8، فالالتقاط يحتفظ بـ 20% من
 * البكسلات الأصلية تحتها. نأخذ عيّنات سطوع من داخل مناطق التغطية فقط (بعد استقرارها) ونقارنها
 * بعيّنات سابقة؛ إن تغيّرت بوضوح (وتأكّد ذلك مرتين) => النص الأصلي تغيّر.
 *
 * الحالات:
 *  IDLE     : لا تغطية. مقارنة بصمة المنطقة كل دورة؛ عند التغيّر ثم الاستقرار => OCR.
 *  SETTLING : عُرضت التغطية للتو؛ ننتظر إطاراً يحتويها ونأخذ منه عيّنات الأساس.
 *  SHOWING  : التغطية ظاهرة وثابتة؛ نراقب العيّنات فقط (بدون أي إخفاء/وميض).
 *
 * كل الحالة تعمل على خيط captureThread (لا أقفال). عرض التغطية يتم على الـ Main عبر overlay.
 * OCR وترجمة ML Kit على الجهاز بالكامل.
 */
class ScreenCaptureService : Service(), FloatingOverlayManager.Listener {

    companion object {
        const val ACTION_START = "com.example.gametranslator.START"
        const val ACTION_STOP = "com.example.gametranslator.STOP"
        const val ACTION_TOGGLE = "com.example.gametranslator.TOGGLE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "capture"
        private const val NOTIF_ID = 1
        private const val TAG = "GameTranslator"

        /** تقرؤها الواجهة لمعرفة هل الخدمة تعمل. */
        @Volatile var isRunning = false

        private const val STABLE_MS = 200L            // استقرار النص قبل OCR
        private const val SETTLE_MS = 150L            // بعد عرض التغطية قبل أخذ عيّنات الأساس
        private const val SETTLE_TIMEOUT_MS = 700L
        private const val IDLE_WAIT_MS = 400L         // أقصى انتظار لإطار نظيف بعد إخفاء التغطية
        private const val SIG_COLS = 96
        private const val SIG_ROWS = 36
        private const val PIXEL_DIFF = 40             // تغيّر السطوع (بدون تغطية)
        private const val MASKED_DIFF = 10            // تغيّر السطوع تحت التغطية (20% فقط من الأصل)
        private const val MAX_WATCH_POINTS = 600
        private const val MODEL_WAIT_MS = 6000L
        private const val TRANSLATE_TIMEOUT_MS = 5000L
        private const val CACHE_MAX = 400
    }

    private enum class Phase { IDLE, SETTLING, SHOWING }

    private lateinit var settings: AppSettings
    private lateinit var overlay: FloatingOverlayManager
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler
    private lateinit var scope: CoroutineScope                       // على خيط الالتقاط
    private val mainHandler = Handler(Looper.getMainLooper())
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
    )
    private val modelReady = CompletableDeferred<Unit>()
    private val spaces = Regex("\\s+")

    @Volatile private var scanning = false
    @Volatile private var sx = 1f      // معامل تصغير الالتقاط (عرض)
    @Volatile private var sy = 1f      // (ارتفاع)
    @Volatile private var capW = 0
    @Volatile private var capH = 0
    @Volatile private var lastError: String? = null

    // ---- حالة خيط captureThread فقط ----
    private var phase = Phase.IDLE
    private var latestImage: Image? = null
    private var frameCounter = 0L
    private var lastSig: IntArray? = null
    private var changePending = false
    private var changeTime = 0L
    private var changeGen = 0
    private var ocrRunning = false
    private var idleReadyFrame = 0L
    private var idleReadyDeadline = 0L
    private var watchPoints = IntArray(0)          // أزواج x,y بإحداثيات الالتقاط
    private var baseline: IntArray? = null
    private var settleAt = 0L
    private var settleStartFrame = 0L
    private var changeStreak = 0
    private var boostUntil = 0L
    private val cache = HashMap<String, String>()

    // ------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(this)
        captureThread = HandlerThread("capture").also { it.start() }
        captureHandler = Handler(captureThread.looper)
        scope = CoroutineScope(SupervisorJob() + captureHandler.asCoroutineDispatcher())
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Screen translator", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> if (!isRunning) startCapture(intent)
            ACTION_TOGGLE -> if (isRunning) overlay.toggleScanning()
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        // 1) إشعار دائم فوراً (إلزامي خلال ثوانٍ من startForegroundService ولقبل getMediaProjection)
        startForegroundCompat()
        isRunning = true
        try {
            // 2) الزر العائم يظهر فوراً قبل أي عمل ثقيل
            overlay = FloatingOverlayManager(this, this).also { it.show() }

            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
                ?: throw IllegalStateException("لا توجد بيانات إذن التقاط الشاشة")

            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mgr.getMediaProjection(resultCode, data)
            projectionCallback = object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }
            proj.registerCallback(projectionCallback!!, mainHandler) // إلزامي في Android 14+
            projection = proj

            setupCapture()
            warmUp()
            prepareTranslator()
        } catch (e: Exception) {
            Log.e(TAG, "start failed", e)
            Toast.makeText(this, "تعذّر تشغيل الخدمة: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun buildNotification(): Notification {
        fun svc(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, ScreenCaptureService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("مترجم الألعاب يعمل")
            .setContentText(if (scanning) "المسح يعمل الآن" else "متوقف مؤقتاً — استخدم الزر العائم ▶")
            .setContentIntent(open)
            .addAction(0, if (scanning) "⏸ إيقاف مؤقت" else "▶ استئناف", svc(ACTION_TOGGLE, 1))
            .addAction(0, "⏹ إنهاء", svc(ACTION_STOP, 2))
            .setOngoing(true)
            .build()
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIF_ID, n)
    }

    /** ImageReader + VirtualDisplay بدقة مخفّضة (إعداد "جودة الالتقاط") لتخفيف حمل المعالج. */
    private fun setupCapture() {
        val size = overlay.screenSize()
        val dpi = resources.displayMetrics.densityDpi
        val scale = settings.captureScalePercent / 100f
        val w = max(64, (size.x * scale).toInt())
        val h = max(64, (size.y * scale).toInt())
        capW = w; capH = h
        sx = w.toFloat() / size.x
        sy = h.toFloat() / size.y

        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader.setOnImageAvailableListener({ onFrame(it) }, captureHandler)

        val old = imageReader
        imageReader = reader
        val vd = virtualDisplay
        if (vd == null) {
            virtualDisplay = projection!!.createVirtualDisplay(
                "GameTranslatorCapture", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, captureHandler
            )
        } else {
            vd.resize(w, h, dpi)
            vd.surface = reader.surface
        }
        captureHandler.post {
            latestImage?.close(); latestImage = null
            old?.close()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (projection != null) {
            setupCapture()
            overlay.onScreenChanged()
            captureHandler.post { resetState() }
        }
    }

    /** تسخين نموذج OCR كي لا يتأخر أول طلب. */
    private fun warmUp() {
        scope.launch {
            try {
                val dummy = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
                recognizer.process(InputImage.fromBitmap(dummy, 0)).await()
            } catch (e: CancellationException) { throw e } catch (e: Exception) { Log.w(TAG, "warmup", e) }
        }
    }

    /** يحمّل نموذج الترجمة (مرة واحدة، يحتاج إنترنت) ويعيد المحاولة حتى ينجح. */
    private fun prepareTranslator() {
        mainScope.launch {
            var warned = false
            while (isActive) {
                try {
                    translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                    runCatching { translator.translate("Hello").await() }   // تسخين
                    modelReady.complete(Unit)
                    Toast.makeText(this@ScreenCaptureService, "نموذج الترجمة جاهز ✓", Toast.LENGTH_SHORT).show()
                    break
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e(TAG, "translator download failed", e)
                    warned = true   // الترجمة عبر الإنترنت تعمل كبديل حتى يجهز النموذج
                    delay(10_000)
                }
            }
        }
    }

    // ---------------------------------------------------- overlay callbacks (Main thread)

    override fun onScanStateChanged(scanning: Boolean) {
        this.scanning = scanning
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        captureHandler.removeCallbacks(tickRunnable)
        captureHandler.post {
            resetState()
            if (scanning) captureHandler.post(tickRunnable)
        }
    }

    override fun onCloseRequested() { stopSelf() }

    /** ضغطة في اللعبة: افحص تغيّر الحوار فوراً (دون انتظار الدورة، وبتأكيد واحد). */
    override fun onUserTap() {
        captureHandler.post { boostUntil = SystemClock.uptimeMillis() + 1000 }
        captureHandler.postDelayed(quickTick, 150)
        captureHandler.postDelayed(quickTick, 400)
    }

    private val quickTick = Runnable {
        if (scanning) try { tick() } catch (e: Exception) { Log.e(TAG, "quick tick", e) }
    }

    private fun resetState() {
        phase = Phase.IDLE
        lastSig = null; baseline = null
        lastProcessedFrame = -1L
        nextOcrAt = 0L
        watchPoints = IntArray(0)
        changePending = false
        changeStreak = 0
        idleReadyDeadline = 0L
        changeGen++
    }

    // ------------------------------------------------------------ frames

    /** نحتفظ بأحدث إطار فقط. */
    private fun onFrame(reader: ImageReader) {
        val img = try { reader.acquireLatestImage() } catch (e: Exception) { null } ?: return
        latestImage?.close()
        latestImage = img
        frameCounter++
    }

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!scanning) return
            try { tick() } catch (e: Exception) { Log.e(TAG, "tick error", e) }
            captureHandler.postDelayed(this, settings.scanIntervalMs.toLong())
        }
    }

    private var lastOrientCheck = 0L
    private var lastProcessedFrame = -1L
    private var nextOcrAt = 0L

    private fun tick() {
        val img = latestImage ?: return
        val now = SystemClock.uptimeMillis()

        // حارس التدوير: إن اختلف اتجاه الشاشة عن اتجاه الالتقاط أعد بناء الالتقاط
        if (now - lastOrientCheck > 1000) {
            lastOrientCheck = now
            val s = overlay.screenSize()
            if ((s.x > s.y) != (capW > capH)) {
                lastOrientCheck = now + 1500
                mainHandler.post { rebuildForRotation() }
                return
            }
        }
        when (phase) {
            Phase.IDLE -> tickIdle(img, now)
            Phase.SETTLING -> {
                val ready = now >= settleAt && frameCounter > settleStartFrame
                if (ready || now >= settleAt + SETTLE_TIMEOUT_MS) {
                    baseline = sampleWatch(img)
                    lastProcessedFrame = frameCounter
                    changeStreak = 0
                    phase = Phase.SHOWING
                }
            }
            Phase.SHOWING -> tickShowing(img, now)
        }
    }

    private fun rebuildForRotation() {
        if (projection == null) return
        setupCapture()
        overlay.onScreenChanged()
        captureHandler.post { resetState() }
    }

    private fun tickIdle(img: Image, now: Long) {
        // بعد إخفاء التغطية انتظر إطاراً جديداً (نظيفاً) قبل المقارنة
        if (frameCounter <= idleReadyFrame && now < idleReadyDeadline) return
        if (now < nextOcrAt) return
        // لا إطار جديد = الشاشة ثابتة = لا حاجة للمقارنة (يوفّر المعالج)
        if (frameCounter == lastProcessedFrame && !changePending) return
        lastProcessedFrame = frameCounter

        val roi = clamp(toCap(overlay.getScanRect()), img.width, img.height)
        if (roi == null) {
            overlay.setStatus("⚠ منطقة المسح خارج الشاشة — اضغط ⛶ وحدّدها")
            return
        }
        val sig = sigOf(img, roi)
        val prev = lastSig
        if (prev == null || hasChanged(prev, sig)) {
            lastSig = sig
            changePending = true
            changeTime = now
            changeGen++
        }
        if (changePending && !ocrRunning && now - changeTime >= STABLE_MS) {
            changePending = false
            startOcr(img, roi, sig)
        }
    }

    /** التغطية ظاهرة: راقب عيّنات داخل مناطقها فقط. لا إخفاء ولا وميض هنا. */
    private fun tickShowing(img: Image, now: Long) {
        val base = baseline ?: return
        if (watchPoints.isEmpty()) return
        if (frameCounter == lastProcessedFrame && changeStreak == 0) return   // لا إطار جديد
        lastProcessedFrame = frameCounter

        val cur = sampleWatch(img)
        var diff = 0
        for (i in base.indices) if (abs(cur[i] - base[i]) > MASKED_DIFF) diff++

        val need = max(2, 22 - 2 * settings.changeSensitivity)
        changeStreak = if (diff >= need) changeStreak + 1 else 0
        val confirm = if (now < boostUntil) 1 else 2
        if (changeStreak >= confirm) onTextChanged(now)
    }

    /** الحالة الوحيدة التي تُخفى فيها التغطية: النص الأصلي تغيّر فعلاً. */
    private fun onTextChanged(now: Long) {
        overlay.setMasksVisible(false)
        phase = Phase.IDLE
        idleReadyFrame = frameCounter
        idleReadyDeadline = now + IDLE_WAIT_MS
        lastSig = null            // يُحتسب تغيّراً فيبدأ انتظار الاستقرار
        lastProcessedFrame = -1L
        changePending = false
        changeStreak = 0
        changeGen++
    }

    // ------------------------------------------------------------ OCR + translate

    private fun startOcr(img: Image, roi: Rect, sig: IntArray) {
        val p = img.planes[0]
        val bmp = cropRegion(p.buffer, p.rowStride, p.pixelStride, roi)
        val gen = changeGen
        ocrRunning = true
        overlay.setStatus("⏳ جارٍ القراءة والترجمة…")
        scope.launch {
            try {
                val items = recognizeAndTranslate(bmp, roi)
                if (!scanning || gen != changeGen) return@launch   // تغيّر الحوار أثناء المعالجة
                when {
                    items == null -> {                              // فشلت الترجمة: أعد المحاولة بعد 3 ثوانٍ
                        nextOcrAt = SystemClock.uptimeMillis() + 3000
                        lastSig = null
                        lastProcessedFrame = -1L
                    }
                    items.isEmpty() -> {
                        overlay.clearMasks()
                        phase = Phase.IDLE
                    }
                    else -> {
                        overlay.showMasks(items)
                        watchPoints = buildWatchPoints(items)
                        settleStartFrame = frameCounter
                        settleAt = SystemClock.uptimeMillis() + SETTLE_MS
                        phase = Phase.SETTLING
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "ocr error", e)
                overlay.setStatus("⚠ خطأ: ${e.message}")
                lastSig = null
                lastProcessedFrame = -1L
                nextOcrAt = SystemClock.uptimeMillis() + 3000
            } finally {
                ocrRunning = false
            }
        }
    }

    /** null = فشلت الترجمة (تُعاد المحاولة)، قائمة فارغة = لا يوجد نص إنجليزي. */
    private suspend fun recognizeAndTranslate(bmp: Bitmap, roi: Rect): List<MaskItem>? {
        // تكبير 2× بالأقرب للمناطق الصغيرة يحسّن قراءة خطوط البكسل ولا يكلّف كثيراً
        val s = if (settings.sharpenSmallText || bmp.width * bmp.height < 500_000) 2 else 1
        val input = if (s > 1) Bitmap.createScaledBitmap(bmp, bmp.width * s, bmp.height * s, false) else bmp
        val result = recognizer.process(InputImage.fromBitmap(input, 0)).await()

        // إنجليزي فقط: كتلة فيها حرفان لاتينيان على الأقل
        val blocks = result.textBlocks.filter { b ->
            b.boundingBox != null && b.text.count { it in 'A'..'Z' || it in 'a'..'z' } >= 2
        }
        if (blocks.isEmpty()) {
            overlay.setStatus("لا يوجد نص إنجليزي داخل المربع")
            return emptyList()
        }

        lastError = null
        val items = coroutineScope {
            blocks.map { b ->
                async {
                    val bb = b.boundingBox!!
                    val src = spaces.replace(b.text, " ").trim()
                    val ar = translateCached(src)
                    if (ar == null) null else MaskItem(
                        toScreen(Rect(roi.left + bb.left / s, roi.top + bb.top / s,
                            roi.left + bb.right / s, roi.top + bb.bottom / s)),
                        ar, b.lines.size
                    )
                }
            }.awaitAll().filterNotNull()
        }
        if (items.isEmpty()) {
            overlay.setStatus("⚠ فشلت الترجمة" + (lastError?.let { ": $it" } ?: "") + " — تحقق من الإنترنت")
            return null
        }
        overlay.setStatus(null)
        return items
    }

    /** ML Kit على الجهاز إن كان النموذج جاهزاً، وإلا ترجمة الإنترنت فوراً (بدون انتظار التنزيل). */
    private suspend fun translateCached(src: String): String? {
        cache[src]?.let { return it }
        var out: String? = null
        if (modelReady.isCompleted) {
            out = try {
                withTimeoutOrNull(TRANSLATE_TIMEOUT_MS) { translator.translate(src).await() }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { null }
        }
        if (out.isNullOrBlank()) {
            out = try {
                withContext(Dispatchers.IO) { OnlineTranslator.translate(src) }
            } catch (e: CancellationException) { throw e } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
                null
            }
        }
        if (!out.isNullOrBlank()) {
            if (cache.size >= CACHE_MAX) cache.clear()
            cache[src] = out
        }
        return out
    }

    // ------------------------------------------------------------ pixels / coords

    private fun toCap(r: Rect) = Rect((r.left * sx).toInt(), (r.top * sy).toInt(),
        (r.right * sx).toInt(), (r.bottom * sy).toInt())

    private fun toScreen(r: Rect) = Rect((r.left / sx).toInt(), (r.top / sy).toInt(),
        (r.right / sx).toInt(), (r.bottom / sy).toInt())

    private fun clamp(r: Rect, w: Int, h: Int): Rect? {
        val c = Rect(maxOf(0, r.left), maxOf(0, r.top), minOf(w, r.right), minOf(h, r.bottom))
        return if (c.width() < 8 || c.height() < 8) null else c
    }

    private fun lum(buf: ByteBuffer, i: Int): Int =
        ((buf.get(i).toInt() and 0xFF) * 3 + (buf.get(i + 1).toInt() and 0xFF) * 6 +
                (buf.get(i + 2).toInt() and 0xFF)) / 10

    private fun sigOf(img: Image, r: Rect): IntArray {
        val p = img.planes[0]
        val buf = p.buffer
        val sig = IntArray(SIG_COLS * SIG_ROWS)
        var k = 0
        for (j in 0 until SIG_ROWS) {
            val y = r.top + r.height() * j / SIG_ROWS
            for (i in 0 until SIG_COLS) {
                val x = r.left + r.width() * i / SIG_COLS
                sig[k++] = lum(buf, y * p.rowStride + x * p.pixelStride)
            }
        }
        return sig
    }

    private fun hasChanged(a: IntArray, b: IntArray): Boolean {
        var diff = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > PIXEL_DIFF && ++diff >= 2) return true
        return false
    }

    /** نقاط عيّنات موزعة داخل مستطيلات التغطية (بإحداثيات الالتقاط). */
    private fun buildWatchPoints(items: List<MaskItem>): IntArray {
        val rects = items.mapNotNull { clamp(toCap(it.rect), capW, capH) }
        if (rects.isEmpty()) return IntArray(0)
        val area = rects.sumOf { it.width().toLong() * it.height() }
        val step = max(4, sqrt(area.toDouble() / MAX_WATCH_POINTS).toInt())
        val out = ArrayList<Int>()
        for (r in rects) {
            var y = r.top
            while (y < r.bottom) {
                var x = r.left
                while (x < r.right) { out.add(x); out.add(y); x += step }
                y += step
            }
        }
        return out.toIntArray()
    }

    private fun sampleWatch(img: Image): IntArray {
        val p = img.planes[0]
        val buf = p.buffer
        val pts = watchPoints
        val out = IntArray(pts.size / 2)
        for (i in out.indices) out[i] = lum(buf, pts[2 * i + 1] * p.rowStride + pts[2 * i] * p.pixelStride)
        return out
    }

    private fun cropRegion(buf: ByteBuffer, rowStride: Int, pixelStride: Int, r: Rect): Bitmap {
        val w = r.width(); val h = r.height()
        val rowBytes = w * pixelStride
        val out = ByteArray(rowBytes * h)
        for (row in 0 until h) {
            buf.position((r.top + row) * rowStride + r.left * pixelStride)
            buf.get(out, row * rowBytes, rowBytes)
        }
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also {
            it.copyPixelsFromBuffer(ByteBuffer.wrap(out))
        }
    }

    // ------------------------------------------------------------ cleanup

    override fun onDestroy() {
        isRunning = false
        scanning = false
        scope.cancel()
        mainScope.cancel()
        if (::overlay.isInitialized) overlay.destroy()      // يزيل كل النوافذ العائمة
        captureHandler.removeCallbacksAndMessages(null)
        captureHandler.post { latestImage?.close(); latestImage = null }
        virtualDisplay?.release(); virtualDisplay = null
        imageReader?.close(); imageReader = null
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop(); projection = null
        recognizer.close()
        translator.close()
        captureThread.quitSafely()
        stopForeground(STOP_FOREGROUND_REMOVE)              // يزيل الإشعار
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
