plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.gametranslator"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.gametranslator"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")

    // Coroutines (+ دعم Task.await() الخاص بـ ML Kit)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")

    // ML Kit On-Device
    implementation("com.google.mlkit:text-recognition:16.0.0")   // OCR (Latin/English)
    implementation("com.google.mlkit:translate:17.0.2")          // ترجمة EN -> AR
}

/*
 * في ملف المشروع الرئيسي (build.gradle.kts في الجذر):
 * plugins {
 *     id("com.android.application") version "8.2.2" apply false
 *     id("org.jetbrains.kotlin.android") version "1.9.22" apply false
 * }
 */
